package com.mkstudio.vezba03;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnRegistrujSe).setOnClickListener(this);
        findViewById(R.id.btnOdustani).setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnRegistrujSe:
                this.registracija();
                break;
            case R.id.btnOdustani:
                finish();
                break;
        }
    }

    private void registracija() {
        String ime = ((EditText)findViewById(R.id.etIme)).getText().toString();
        String prezime = ((EditText)findViewById(R.id.etPrezime)).getText().toString();
        if (ime.isEmpty() || prezime.isEmpty()){
            ((TextView)findViewById(R.id.lblPoruka)).setText("Niste ispravno popunili polja!");
        }
        else {
            ((TextView)findViewById(R.id.lblPoruka)).setText("");
            ((EditText)findViewById(R.id.etIme)).setText("");
            ((EditText)findViewById(R.id.etPrezime)).setText("");
            startActivity(new Intent(this, DetaljiActivity.class));
        }
    }
}