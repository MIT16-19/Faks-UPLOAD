package com.mkstudio.vezba03;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetaljiActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalji);
        findViewById(R.id.btnSacuvaj).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnSacuvaj:
                this.sacuvaj();
                break;
        }
    }

    private void sacuvaj() {
        String email = ((EditText)findViewById(R.id.etEmail)).getText().toString();
        String phone = ((EditText)findViewById(R.id.etPhone)).getText().toString();
        String adr = ((EditText)findViewById(R.id.etAdr)).getText().toString();
        if (email.isEmpty() || phone.isEmpty() || adr.isEmpty()){
            ((TextView)findViewById(R.id.lblPoruka2)).setText("Niste ispravno popunili polja!");
        }
        else {
            ((TextView)findViewById(R.id.lblPoruka2)).setText("Promene uspesno sacuvane!");
        }
    }
}