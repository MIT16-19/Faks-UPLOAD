package com.mkstudio.vezba08;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.mkstudio.vezba08.zadaci_db.CSVReader;
import com.mkstudio.vezba08.zadaci_db.CSVWriter;
import com.mkstudio.vezba08.zadaci_db.Zadatak;
import com.mkstudio.vezba08.zadaci_db.ZadatakDBHelper;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG="MainActivity";
    private ZadatakDBHelper zadatakDBHelper;
    private ListView listZadaci;
    private ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        zadatakDBHelper = new ZadatakDBHelper(this);
        listZadaci = (ListView)findViewById(R.id.listZadaci);

        updateUI();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.actionAddZadatak:
                final EditText zadEdit = new EditText(this);
                AlertDialog dialog = new AlertDialog.Builder(this)
                        .setTitle("Dodaj novi zadatak").setMessage("Sta zeliz da uradis").setView(zadEdit)
                        .setPositiveButton("Dodaj", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                String zadatak = String.valueOf(zadEdit.getText());
                                SQLiteDatabase db = zadatakDBHelper.getWritableDatabase();
                                ContentValues values = new ContentValues();
                                values.put(Zadatak.ZadatakEntry.COL_ZAD_TITLE,zadatak);
                                db.insertWithOnConflict(Zadatak.ZadatakEntry.TABELA, null,values,SQLiteDatabase.CONFLICT_REPLACE);
                                db.close();
                                updateUI();
                            }
                        })
                        .setNegativeButton("Odustani",null).create();
                dialog.show();
                return true;
            case R.id.actionExport:
                exportDB();
                return true;
            case R.id.actionLoad:
                importToDB();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void obrisiZadatak(View view){
        View parent = (View)view.getParent();
        TextView zadTextView = (TextView)parent.findViewById(R.id.lblZadatak);
        String zadatak = String.valueOf(zadTextView.getText());
        SQLiteDatabase db = zadatakDBHelper.getWritableDatabase();
        db.delete(Zadatak.ZadatakEntry.TABELA, Zadatak.ZadatakEntry.COL_ZAD_TITLE + " = ?", new String[]{zadatak});
        db.close();
        updateUI();
    }

    private void updateUI(){
        ArrayList<String> zadLista = new ArrayList<>();
        SQLiteDatabase db = zadatakDBHelper.getReadableDatabase();
        Cursor cursor = db.query(Zadatak.ZadatakEntry.TABELA,
                new String[]{Zadatak.ZadatakEntry._ID, Zadatak.ZadatakEntry.COL_ZAD_TITLE},
                null,null,null, null,null);
        while (cursor.moveToNext()){
            int idx = cursor.getColumnIndex(Zadatak.ZadatakEntry.COL_ZAD_TITLE);
            zadLista.add(cursor.getString(idx));
        }
        if(arrayAdapter==null){
            arrayAdapter = new ArrayAdapter<>(this,R.layout.todo_zadatak,R.id.lblZadatak,zadLista);
            listZadaci.setAdapter(arrayAdapter);
        } else {
            arrayAdapter.clear();
            arrayAdapter.addAll(zadLista);
            arrayAdapter.notifyDataSetChanged();
        }
        cursor.close();
        db.close();
    }

    private void exportDB() {
        File exportDir = new File(Environment.getExternalStorageDirectory()+ File.separator + "ZadaciOdZence", "");
        if (!exportDir.exists())
        {
            exportDir.mkdirs();
        }

        File file = new File(exportDir, "ZadaciOdZence.csv");
        try
        {
            file.createNewFile();
            CSVWriter csvWrite = new CSVWriter(new FileWriter(file));
            SQLiteDatabase db = zadatakDBHelper.getReadableDatabase();
            Cursor curCSV = db.rawQuery("SELECT * FROM " + Zadatak.ZadatakEntry.TABELA,null);
            csvWrite.writeNext(curCSV.getColumnNames());
            while(curCSV.moveToNext())
            {
                String arrStr[] ={curCSV.getString(0),curCSV.getString(1)};
                csvWrite.writeNext(arrStr);
            }
            csvWrite.close();
            curCSV.close();
        }
        catch(Exception ex)
        {
            Log.e("MainActivity", ex.getMessage(), ex);
        }
        final EditText etMail = new EditText(this);
        etMail.setInputType(InputType.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Posalji zadatke na email").setMessage("Kome zelis da posaljes zadatke?").setView(etMail)
                .setPositiveButton("Posalji", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String emailString = String.valueOf(etMail.getText());
                        posaljiEmail(emailString);
                    }
                })
                .setNegativeButton("Odustani",null).create();
        dialog.show();
    }

    private void posaljiEmail(String email){
        String file = "ZadaciOdZence.csv";
        File exportDir = new File(Environment.getExternalStorageDirectory()+ File.separator + "ZadaciOdZence", "");
        File filelocation = new File(exportDir, file);
        Uri path = Uri.fromFile(filelocation);
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("vnd.android.cursor.dir/email");
        String to[] = {email};
        emailIntent.putExtra(Intent.EXTRA_EMAIL, to);
        emailIntent.putExtra(Intent.EXTRA_STREAM, path);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Zadaci za ....");
        startActivity(Intent.createChooser(emailIntent , "Posalji email..."));
    }

    private void importToDB(){
        String file = "ZadaciOdZence.csv";
        File exportDir = new File(Environment.getExternalStorageDirectory()+ File.separator + "ZadaciOdZence", "");
        File filelocation = new File(exportDir, file);
        if (filelocation.exists()){
            try {
                int count = 0;
                CSVReader reader = new CSVReader(new FileReader(filelocation));
                String[] nextLine;
                while ((nextLine = reader.readNext()) != null) {
                    if (count != 0){
                        String zadatak = nextLine[1].toString();
                        SQLiteDatabase db = zadatakDBHelper.getWritableDatabase();
                        ContentValues values = new ContentValues();
                        values.put(Zadatak.ZadatakEntry.COL_ZAD_TITLE,zadatak);
                        db.insertWithOnConflict(Zadatak.ZadatakEntry.TABELA, null,values,SQLiteDatabase.CONFLICT_REPLACE);
                        db.close();
                        count++;
                    } else {
                        count++;
                    }
                }
                reader.close();
                filelocation.delete();
                updateUI();
            } catch (IOException ex) {
                Log.e("MainActivity", ex.getMessage(), ex);
            }
        } else {
            Toast.makeText(getApplicationContext(),"Fajl ZadaciOdZence.csv ne postoji!",Toast.LENGTH_SHORT).show();
        }
    }
}