package com.mkstudio.vezba08.zadaci_db;

import android.provider.BaseColumns;

public class Zadatak {
    public static final String DB_NAME = "com.master.listzadatak.db";
    public static final int DB_VERSION = 1;

    public class ZadatakEntry implements BaseColumns{
        public static final String TABELA = "zadaci";
        public static final String COL_ZAD_TITLE = "naziv";
    }
}
