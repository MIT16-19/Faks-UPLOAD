package com.mkstudio.vezba08.zadaci_db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ZadatakDBHelper extends SQLiteOpenHelper {

    public ZadatakDBHelper(Context context){
        super(context, Zadatak.DB_NAME,null,Zadatak.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + Zadatak.ZadatakEntry.TABELA + "(" +
                Zadatak.ZadatakEntry._ID + "INTEGER PRIMARY KEY AUTOINCREMENT," +
                Zadatak.ZadatakEntry.COL_ZAD_TITLE + "TEXT NOT NULL);";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + Zadatak.ZadatakEntry.TABELA);
        onCreate(db);
    }
}
