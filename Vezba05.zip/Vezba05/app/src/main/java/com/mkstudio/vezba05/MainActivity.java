package com.mkstudio.vezba05;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dodajListuSmerova();
        findViewById(R.id.btnUnesi).setOnClickListener(this);
    }

    public void dodajListuSmerova(){
        Spinner spinSmer = (Spinner)findViewById(R.id.spinSmer);
        ArrayList<String> listaSmer = new ArrayList<>();

        listaSmer.add("Informacione tehnologije");
        listaSmer.add("WEB dizajn");
        listaSmer.add("Zastita zivotne sredine");
        listaSmer.add("Drumski saobracaj");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, listaSmer);

        spinSmer.setAdapter(adapter);
    }

    @Override
    public void onClick(View view) {
        Intent i = new Intent(this, PotvrdaPodataka.class);
        Bundle podaci = new Bundle();
        if (view.getId() == R.id.btnUnesi){
            String userName = ((EditText)findViewById(R.id.etUserName)).getText().toString();
            String userPass = ((EditText)findViewById(R.id.etPass)).getText().toString();

            Spinner spinSmer = (Spinner)findViewById(R.id.spinSmer);
            String smer = (String)spinSmer.getSelectedItem();

            Boolean zaposlen = ((Switch)findViewById(R.id.swZaposlen)).isChecked();

            podaci.putString("userName", userName);
            podaci.putString("userPass", userPass);
            podaci.putString("smer", smer);
            podaci.putBoolean("zaposlen", zaposlen);

            i.putExtras(podaci);

            startActivity(i);
        }
    }
}