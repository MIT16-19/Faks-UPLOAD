package com.mkstudio.vezba05;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PotvrdaPodataka extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_potvrda_podataka);

        Bundle podaci = getIntent().getExtras();

        String userName = podaci.getString("userName");
        String userPass = podaci.getString("userPass");
        String smer = podaci.getString("smer");
        Boolean zaposlen = podaci.getBoolean("zaposlen");

        String poruka = "Da li su podaci tacni:\n";
        poruka += "Korisnicko ime:" + userName +"\n";
        poruka += "Sifra:" + userPass +"\n";
        poruka += "Smer:" + smer +"\n";
        poruka += (zaposlen)?"Zaposlen.\n":"Nezaposlen.\n";

        ((TextView)findViewById(R.id.lblPoruka)).setText(poruka);
    }
}