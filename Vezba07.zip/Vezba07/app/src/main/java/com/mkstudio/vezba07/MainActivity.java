package com.mkstudio.vezba07;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button [][] buttons = new Button[3][3];
    private boolean igrac1Pocetak = true;
    private int brojacRundi;
    private int igrac1Poeni;
    private int igrac2Poeni;
    private TextView lblIgrac1;
    private TextView lblIgrac2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lblIgrac1 = findViewById(R.id.lblIgrac1);
        lblIgrac2 = findViewById(R.id.lblIgrac2);
        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                String btnID = "btn" + i + j;
                int resID = getResources().getIdentifier(btnID, "id",getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }
        Button btnReset = findViewById(R.id.btnReset);
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetIgre();
            }
        });
    }

    @Override
    public void onClick(View view) {
        if (!((Button)view).getText().toString().equals("")){
            return;
        }
        if (igrac1Pocetak){
            ((Button)view).setText("X");
        } else {
            ((Button)view).setText("O");
        }
        brojacRundi++;
        if(proveriPobednika()){
            if (igrac1Pocetak){
                igrac1Pobednik();
            } else {
                igrac2Pobednik();
            }
        } else if (brojacRundi==9){
            nereseno();
        } else {
            igrac1Pocetak =! igrac1Pocetak;
        }
    }

    private boolean proveriPobednika(){
        String [][] polje = new String[3][3];
        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                polje[i][j] = buttons[i][j].getText().toString();
            }
        }
        for (int i=0; i<3; i++){
            if (polje[i][0].equals(polje[i][1])
                && polje[i][0].equals(polje[i][2])
                && !polje[i][0].equals("")){
                return true;
            }
        }
        for (int i=0; i<3; i++){
            if (polje[0][i].equals(polje[1][i])
                    && polje[0][i].equals(polje[2][i])
                    && !polje[0][i].equals("")){
                return true;
            }
        }
        if (polje[0][0].equals(polje[1][1])
                && polje[0][0].equals(polje[2][2])
                && !polje[0][0].equals("")){
            return true;
        }
        if (polje[0][2].equals(polje[1][1])
                && polje[0][2].equals(polje[2][0])
                && !polje[0][2].equals("")){
            return true;
        }
        return false;
    }

    private void igrac1Pobednik(){
        igrac1Poeni++;
        Toast.makeText(this,"Igrac 1 je pobednik", Toast.LENGTH_SHORT).show();
        dopuniPoene();
        resetujTablu();
    }

    private void igrac2Pobednik(){
        igrac2Poeni++;
        Toast.makeText(this,"Igrac 2 je pobednik", Toast.LENGTH_SHORT).show();
        dopuniPoene();
        resetujTablu();
    }

    private void nereseno(){
        Toast.makeText(this,"Nereseno", Toast.LENGTH_SHORT).show();
        resetujTablu();
    }

    private void dopuniPoene(){
        lblIgrac1.setText("Igrac 1: "+igrac1Poeni);
        lblIgrac2.setText("Igrac 2: "+igrac2Poeni);
    }

    private void resetujTablu(){
        for(int i = 0; i<3 ;i++){
            for(int j = 0; j<3 ; j++){
                buttons[i][j].setText("");
            }
        }
        brojacRundi = 0;
        igrac1Pocetak = true;
    }

    private void resetIgre(){
        igrac1Poeni = 0;
        igrac2Poeni = 0;
        dopuniPoene();
        resetujTablu();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("brojacRundi", brojacRundi);
        outState.putInt("igrac1Poeni", igrac1Poeni);
        outState.putInt("igrac2Poeni", igrac2Poeni);
        outState.putBoolean("igrac1Pocetak", igrac1Pocetak);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        brojacRundi = savedInstanceState.getInt("brojacRundi");
        igrac1Poeni = savedInstanceState.getInt("igrac1Poeni");
        igrac2Poeni = savedInstanceState.getInt("igrac2Poeni");
        igrac1Pocetak = savedInstanceState.getBoolean("igrac1Pocetak");
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Izlaz")
                .setMessage("Da li želite da ugasite igru?")
                .setPositiveButton("Da", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("Ne", null)
                .show();
    }
}