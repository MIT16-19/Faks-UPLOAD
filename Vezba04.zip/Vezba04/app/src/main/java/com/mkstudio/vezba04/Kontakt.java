package com.mkstudio.vezba04;

public class Kontakt {
    public enum TIP_KONTAKATA { EMAIL, PHONE, LINKEDIN}
    private TIP_KONTAKATA tipKontakata;
    private String ime, vrednost;

    public Kontakt(TIP_KONTAKATA tipKontakata, String ime, String vrednost) {
        this.tipKontakata = tipKontakata;
        this.ime = ime;
        this.vrednost = vrednost;
    }

    public TIP_KONTAKATA getTipKontakata() {
        return tipKontakata;
    }

    public String getIme() {
        return ime;
    }

    public String getVrednost() {
        return vrednost;
    }
}
