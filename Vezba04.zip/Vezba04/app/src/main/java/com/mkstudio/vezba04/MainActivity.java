package com.mkstudio.vezba04;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<Kontakt> list = KontaktiApi.getMojeKontakte();

        LinearLayout mainScrollView = (LinearLayout)findViewById(R.id.mainScrollView);

        LayoutInflater inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        for (Kontakt kontakt:list){
            ConstraintLayout item = (ConstraintLayout) inflater.inflate(R.layout.custom_view, null);
            ((TextView) item.findViewById(R.id.lblIme)).setText((kontakt.getIme()));
            ((TextView) item.findViewById(R.id.lblVrednost)).setText((kontakt.getVrednost()));

            ImageView imgIcon = (ImageView) item.findViewById(R.id.imgIcon);

            switch (kontakt.getTipKontakata()){
                case EMAIL:
                    imgIcon.setImageResource(R.drawable.img_email);
                    break;
                case PHONE:
                    imgIcon.setImageResource(R.drawable.img_phone);
                    break;
                case LINKEDIN:
                    imgIcon.setImageResource(R.drawable.img_linked);
                    break;
            }

            mainScrollView.addView(item);
        }
    }
}