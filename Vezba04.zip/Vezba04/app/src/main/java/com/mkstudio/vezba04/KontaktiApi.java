package com.mkstudio.vezba04;

import java.util.LinkedList;
import java.util.List;

public class KontaktiApi {
    public static List<Kontakt> getMojeKontakte(){
        List<Kontakt> list = new LinkedList<>();

        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.PHONE,"Marko Dragic","123marko"));
        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.EMAIL,"Milan Bojanic","456milan"));
        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.LINKEDIN,"Dragan Nikolic","789dragan"));
        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.PHONE,"Nenad Markovic","987nenad"));
        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.EMAIL,"Branko Milosevic","654branko"));
        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.PHONE,"Aleksa Petrovic","321aleksa"));
        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.LINKEDIN,"Mirko Milanic","147mirko"));
        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.PHONE,"Petar Nenadovic","258petar"));
        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.EMAIL,"Bojan Mirkovic","369bojan"));
        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.LINKEDIN,"Milos Aleksic","963milos"));
        list.add(new Kontakt(Kontakt.TIP_KONTAKATA.LINKEDIN,"Nikola Brankovic","852nikola"));

        return list;
    }
}
